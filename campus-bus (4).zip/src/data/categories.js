/**
 * Landmark categories, styled after the "Marauder's Map of VIT" poster:
 * pastel pills over satellite imagery, colour-coded by what the place is.
 */
export const CATEGORIES = {
  food:     { label: 'Food & restaurants',   bg: '#f7b8c8', fg: '#4a1020', icon: '🍽' },
  academic: { label: 'Academic buildings',   bg: '#a9d9a4', fg: '#0f2c11', icon: '🎓' },
  sports:   { label: 'Sports',               bg: '#a6cfe8', fg: '#0a2436', icon: '🏅' },
  gym:      { label: 'Gyms',                 bg: '#f2e3a0', fg: '#3a2f05', icon: '🏋' },
  other:    { label: 'Other landmarks',      bg: '#d5b9e6', fg: '#2c113c', icon: '📍' },
  store:    { label: 'Stores & pharmacies',  bg: '#dbb99c', fg: '#33200d', icon: '🛒' },
}

export const CATEGORY_LIST = Object.entries(CATEGORIES).map(([id, c]) => ({ id, ...c }))
export const catOf = (id) => CATEGORIES[id] ?? CATEGORIES.other
