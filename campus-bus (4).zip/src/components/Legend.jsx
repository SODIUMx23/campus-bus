/**
 * Category legend, collapsible so it doesn't eat the map on a phone.
 * Doubles as a filter: tap a category to show only those landmarks.
 */
import { useState } from 'react'
import { CATEGORY_LIST } from '../data/categories'

export default function Legend({ hidden, onToggle, showLandmarks, onToggleAll }) {
  const [open, setOpen] = useState(false)

  return (
    <div className={`legend ${open ? 'open' : ''}`}>
      <button className="legend-head" onClick={() => setOpen((o) => !o)}>
        <span>🗺 Legend</span>
        <b>{open ? '▾' : '▴'}</b>
      </button>

      {open && (
        <div className="legend-body">
          <label className="legend-all">
            <input type="checkbox" checked={showLandmarks} onChange={onToggleAll} />
            Show landmarks
          </label>
          {CATEGORY_LIST.map((c) => (
            <button
              key={c.id}
              className={`legend-row ${hidden.has(c.id) ? 'off' : ''}`}
              onClick={() => onToggle(c.id)}
              disabled={!showLandmarks}
            >
              <span className="legend-swatch" style={{ background: c.bg }} />
              {c.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
