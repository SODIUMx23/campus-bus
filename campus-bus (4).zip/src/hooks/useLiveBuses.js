/**
 * Real buses, from the transport layer.
 *
 * Three things happen here that matter for how accurate the map *looks*:
 *
 *  1. SNAPPING — a bus within SNAP_MAX metres of its route is drawn on the
 *     route line, not at the raw GPS point. Buses drive on roads; a marker
 *     sitting 8 m into a building reads as "broken" even when the fix is good.
 *     Beyond that distance we show the raw position and flag it, because
 *     snapping a genuinely off-route bus would be a lie.
 *
 *  2. SMOOTHING — positions arrive every ~3 s. Jumping between them looks
 *     jittery, so we ease the drawn position toward the target each frame.
 *
 *  3. STALENESS — anything quiet for over a minute is greyed out rather than
 *     left frozen in place.
 */
import { useEffect, useRef, useState } from 'react'
import { transport, STALE_MS } from '../lib/transport'
import { ROUTE_BY_ID, FRAME } from '../data/campus'
import { projectOnPath, pointAt } from '../lib/geo'

/** Snap to the route line when the fix is at least this close to it. */
export const SNAP_MAX_M = 45
/** Fraction of the remaining gap closed each frame (~60fps). */
const EASE = 0.12

export function useLiveBuses() {
  const [raw, setRaw] = useState([])
  const [, force] = useState(0)
  const shown = useRef(new Map())   // trip_id -> { x, y } currently drawn

  useEffect(() => transport.subscribe(setRaw), [])

  // Resolve each record to a target position, snapping where sensible.
  const targets = raw
    .filter((r) => ROUTE_BY_ID[r.route_id])
    .map((r) => {
      const route = ROUTE_BY_ID[r.route_id]
      const snap = projectOnPath(route.measured, r.lat, r.lng, FRAME)
      const onRoute = snap.off <= SNAP_MAX_M

      // Snapped buses are drawn at their projection on the polyline.
      const p = onRoute ? pointAt(route.measured, snap.d) : FRAME.toXY(r.lat, r.lng)
      const lat = onRoute ? p.lat : r.lat
      const lng = onRoute ? p.lng : r.lng

      const next = route.stopOffsets.reduce((best, s) => {
        const total = route.measured.total
        const gap = ((s.d - snap.d) % total + total) % total
        return gap < best.gap ? { gap, id: s.id } : best
      }, { gap: Infinity, id: route.stopOffsets[0]?.id })

      return {
        id: r.trip_id,
        live: true,
        stale: Date.now() - r.updated_at > STALE_MS,
        ageSec: Math.round((Date.now() - r.updated_at) / 1000),
        updatedAt: r.updated_at,
        routeId: r.route_id,
        label: r.bus_name ?? 'Bus',
        plate: 'live GPS',
        rawLat: r.lat,
        rawLng: r.lng,
        lat, lng,
        tx: p.x, ty: p.y,               // target position, metre frame
        offRoute: !onRoute,
        offRouteM: Math.round(snap.off),
        accuracy: r.accuracy_m,
        d: snap.d,
        speedKmh: r.speed_kmh ?? 0,
        speedFactor: 1,
        dwellLeft: 0,
        occupancy: r.occupancy ?? 0,
        capacity: r.capacity ?? 45,
        delayMin: 0,
        direction: route.directionAt(snap.d),
        nextStopId: next.id,
      }
    })

  // Ease the drawn position toward the target so movement is continuous.
  useEffect(() => {
    if (!targets.length) return
    let raf
    const step = () => {
      let moved = false
      for (const b of targets) {
        const cur = shown.current.get(b.id)
        if (!cur) { shown.current.set(b.id, { x: b.tx, y: b.ty }); moved = true; continue }
        const dx = b.tx - cur.x
        const dy = b.ty - cur.y
        if (Math.abs(dx) > 0.05 || Math.abs(dy) > 0.05) {
          cur.x += dx * EASE
          cur.y += dy * EASE
          moved = true
        }
      }
      // drop buses that have gone
      for (const id of [...shown.current.keys()]) {
        if (!targets.some((b) => b.id === id)) shown.current.delete(id)
      }
      if (moved) force((n) => n + 1)
      raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [targets])

  return targets.map((b) => {
    const cur = shown.current.get(b.id)
    return cur ? { ...b, x: cur.x, y: cur.y } : { ...b, x: b.tx, y: b.ty }
  })
}
